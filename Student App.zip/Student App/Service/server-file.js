// const config = require('./common/config-util')
const route = require('./routes/route');

/*******************NPM Libraries*****************************/

const express = require('express');
const app = express();
const bodyParser = require("body-parser");

/****************************Middleware***********************************************/

app.use(bodyParser.json({limit: '20mb'}));
app.use(bodyParser.urlencoded({limit: '20mb', extended: true}));
// app.use(express.static(__dirname));

/*************************************************Routes********************************************/

app.use('/student',route);

/*******************************Server Hosting*****************************************/
const server = app.listen(8040, function() {
    console.log('Node server is running..' + 8040);
});