const MongoDB = require('../common/mongo-util');

class UserService {
    constructor(config) {
         this.mongoDB = new MongoDB("mongodb://127.0.0.1:27017");
    }
    async findStudents(){
          console.log('in find function');
          let result=await this.mongoDB.findRecord({}, {});
           return result;     
    }

    async insertStudent(body){
        console.log('in insert function');
        let result=await this.mongoDB.createRecord(body);
         return result;     
  }

    async updateStudent(data){
        try{
            let query = {'phone' : data.oldphone};
            let values = {
                $set : {
                    "name" : data.name,
                    "dob" : data.dob,
                    "gender" : data.gender,
                    "phone" : data.phone,
                    "subject" : data.subject
                }
            };
            let result = await this.mongoDB.updateRecord(query,values);
            return result;
        }catch(e){
            console.log(e);
        }
        
    } 
    
    async deleteStudent(phone){
        try{
            let query = {'phone' : phone};
            let result = await this.mongoDB.deleteRecord(query);
            return result;
        }catch(e){
            console.log(e);
        }
        
    }
    
}


module.exports = UserService;