const UserService = require('../service/service');

class FirstController {
    constructor(){
      this.userService = new UserService();
      this.getStudentData=this.getStudentData.bind(this); 
      this.insertStudent = this.insertStudent.bind(this);
      this.updateStudent = this.updateStudent.bind(this);
      this.deleteStudent = this.deleteStudent.bind(this);
    }
   
    async getStudentData(req,res){
        let json = {};
        try{
            console.log("INSIDE GET STUDENT DATA CONTROLLER");
            let data = await this.userService.findStudents();
            console.log(data);
            if(data.length){
                json = {
                    "message" : "SUCCESS",
                    "response" : data
                }
            }else{
                json = {
                    "message" : "FAILURE",
                }
            }
            res.send(json);
            res.end();
            return;
        }catch(e){
            console.log(e);
            json = {
                "message" : "An Error Occurred. Please Try Again"
            }
            res.send(json);
            res.end();
            return;
        }
    }

    async insertStudent(req,res){
        console.log("INSIDE INSERT STUDENT CONTROLLER");
        let json = {};
        try{
            let reqBody = req.body;
            let data = await this.userService.insertStudent(reqBody);
            console.log(data);
            json = {
                "message" : "SUCCESS"
            } 
            res.send(json);
            res.end();
            return;
        }catch(e){
            json = {
                "message" : "An Error Occurred . Please Try Again"
            }
            res.send(json);
            res.end();
            return;
        }
    }

    async updateStudent(req,res){
        console.log("INSIDE UPDATE STUDENT CONTROLLER");
        let json = {};
        try{
            let reqBody = req.body;
            let data = await this.userService.updateStudent(reqBody);
            console.log("========",data);
            if(data.modifiedCount == 1){
                json = {
                    "message" : "SUCCESS"
                }
            }else{
                json = {
                    "message" : "FAILURE"
                }
            }
            res.send(json);
            res.end();
            return;
        }catch(e){

        }
    }

    async deleteStudent(req,res){
        console.log("INSIDE DELETE STUDENT CONTROLLER");
        let json = {};
        try{
            let phone  = req.body.phone;
            let data = await this.userService.deleteStudent(phone);
            console.log("-----data",data);
            if(data.deletedCount == 1){
                json={
                    "message" : "SUCCESS"
                }
            }else{
                json = {
                    "message" : "FAILURE"
                }
            }
            res.send(json);
                res.end();
                return;
        }catch(e){
            json = {
                "message" : "An Error Occurred. Please Try Again"
            }
            res.send(json);
            res.end();
            return;
        }
    }

}
module.exports = FirstController;
