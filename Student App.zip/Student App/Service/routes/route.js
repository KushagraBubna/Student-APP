const express = require('express');
const router = express.Router();

const FirstController = require('../controller/controller');
const firstController = new FirstController();


router.get('/getStudents',firstController.getStudentData)
router.post('/insertStudent',firstController.insertStudent)
router.post('/updateStudent',firstController.updateStudent);
router.post('/deleteStudent',firstController.deleteStudent);



module.exports = router;


