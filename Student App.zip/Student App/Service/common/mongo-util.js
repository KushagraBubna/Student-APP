const mongoClient = require('mongodb').MongoClient;

class MongoDB {
    constructor(url) {
        this.url = url;
    }

    createRecord(document) {

        return new Promise((resolve, reject) => {
            mongoClient.connect(this.url, function (error, client) {
                if (error) {
                    reject(error);
                } else {
                    let db = client.db("test")
                    db.collection("students").insertOne(document, function (err, res) {
                        if (err) {
                            reject(err);
                        } else {
                            client.close();
                            resolve(res);
                        }
                    });
                }
            });
        });
    };

    findRecord(query, fields) {
        return new Promise((resolve, reject) => {
            mongoClient.connect(this.url, function (error, client) {
                if (error) {
                    reject(error);
                } else {
                    // console.log("--------",db);
                    if (!fields) {
                        fields = {};
                    }
                    let db = client.db("test")
                    db.collection("students").find(query, fields).toArray(function (err, res) {
                        if (err) {
                            reject(err);
                        } else {
                            client.close();
                            resolve(res);
                        }
                    });
                }
            });
        });
    };

    updateRecord(query, values) {
        return new Promise((resolve, reject) => {
            mongoClient.connect(this.url, function (error, client) {
                if (error) {
                    reject(error);
                } else {
                    let db = client.db("test");
                    db.collection("students").updateOne(query, values, function (err, res) {
                        if (err) {
                            reject(err);
                        } else {
                            client.close();
                            resolve(res);
                        }
                    });
                }
            });
        });
    };

    deleteRecord(query) {
        return new Promise((resolve, reject) => {
            mongoClient.connect(this.url, function (error, client) {
                if (error) {
                    reject(error);
                } else {
                    let db = client.db('test')
                    db.collection("students").deleteOne(query, function (err, res) {
                        if (err) {
                            reject(err);
                        } else {
                            // console.log(res);
                            client.close();
                            resolve(res);
                        }
                    });
                }
            });
        });
    };

}

module.exports = MongoDB;

